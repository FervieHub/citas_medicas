
package Entidades;


public class Parametricas {
    
}
