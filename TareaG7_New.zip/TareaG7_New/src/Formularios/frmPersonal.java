package Formularios;

import ConexionDB.ConexionBase;
import Entidades.*;
import java.sql.*;
import java.sql.Connection;
import java.sql.Statement;
import java.sql.ResultSet;
import java.sql.PreparedStatement;
import java.sql.DriverManager;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

public class frmPersonal extends javax.swing.JInternalFrame {
    Connection con3 = null;
    Statement st = null;
    ResultSet rs = null;
    DefaultTableModel TablaPersonal = new DefaultTableModel();
    String transaccion = "";
    boolean ValidarDocumento = false;

    /**
     * Creates new form frmPersonal
     */
    public frmPersonal() {
        initComponents();
        
        Deshabilitar();
        CargarPerfil();
        CargarEspecialidad();
        CargarGenero();
        CargarTipoDocumento();
        CargarDistrito();
        
        CargarPersonal();
        
        lblIdPerfil.setVisible(false);
        lblIdEspecialidad.setVisible(false);
        lblIdGenero.setVisible(false);
        lblIdTipoDocumento.setVisible(false);
        lblIdDistrito.setVisible(false);
    }
    
    public void Habilitar(){
        //txtId.setEnabled(true);
        cboPerfil.setEnabled(true);
        cboEspecialidad.setEnabled(true);
        txtNombre.setEnabled(true);
        txtPaterno.setEnabled(true);
        txtMaterno.setEnabled(true);
        cboGenero.setEnabled(true);
        txtFechaNacimiento.setEnabled(true);
        cboTipoDocumento.setEnabled(true);
        txtNumero.setEnabled(true);
        cboDistrito.setEnabled(true);
        txtDireccion.setEnabled(true);
        txtTelefono.setEnabled(true);
        txtCelular.setEnabled(true);
        txtCorreo.setEnabled(true);
        chkEstado.setEnabled(true);
        
        btnNuevo.setEnabled(false);
        btnEditar.setEnabled(false);
        btnGuardar.setEnabled(true);
        btnCancelar.setEnabled(true);
    }
    
    public void Deshabilitar(){
        txtId.setEnabled(false);
        cboPerfil.setEnabled(false);
        cboEspecialidad.setEnabled(false);
        txtNombre.setEnabled(false);
        txtPaterno.setEnabled(false);
        txtMaterno.setEnabled(false);
        cboGenero.setEnabled(false);
        txtFechaNacimiento.setEnabled(false);
        cboTipoDocumento.setEnabled(false);
        txtNumero.setEnabled(false);
        cboDistrito.setEnabled(false);
        txtDireccion.setEnabled(false);
        txtTelefono.setEnabled(false);
        txtCelular.setEnabled(false);
        txtCorreo.setEnabled(false);
        chkEstado.setEnabled(false);
        
        btnNuevo.setEnabled(true);
        btnEditar.setEnabled(false);
        btnGuardar.setEnabled(false);
        btnCancelar.setEnabled(false);
    }
    
    public void Limpiar(){
        txtId.setText("");
        cboPerfil.setSelectedIndex(0);
        cboEspecialidad.setSelectedIndex(0);
        txtNombre.setText("");
        txtPaterno.setText("");
        txtMaterno.setText("");
        cboGenero.setSelectedIndex(0);
        txtFechaNacimiento.setText("");
        cboTipoDocumento.setSelectedIndex(0);
        txtNumero.setText("");
        cboDistrito.setSelectedIndex(0);
        txtDireccion.setText("");
        txtTelefono.setText("");
        txtCelular.setText("");
        txtCorreo.setText("");
        chkEstado.setSelected(false);
    }
    
    public void CargarPersonal(){
        String titulos[] = {"N°", "Id", "Personal", "Especialidad"};
        TablaPersonal = new DefaultTableModel(null, titulos);
        String[] registros = new String[100];
        String SQLBuscar = "Select * FROM vst_personal ORDER BY nombre, paterno, materno ASC";
        ConexionBase Conectado = new ConexionBase();
        con3 = Conectado.getConnection();

        try {
            st = (Statement) con3.createStatement();
            rs = st.executeQuery(SQLBuscar);
            
            int count = 0;
            
            while (rs.next()) {
                count++;
                registros[0] = String.valueOf(count);
                registros[1] = rs.getString("id");
                registros[2] = rs.getString("nombre") + " " + rs.getString("paterno") + " " + rs.getString("materno");
                TablaPersonal.addRow(registros);
            }
            
            tblPersonal.setModel(TablaPersonal);
            
            tblPersonal.getColumnModel().getColumn(0).setPreferredWidth(50);
            
            tblPersonal.getColumnModel().getColumn(1).setMaxWidth(0);
            tblPersonal.getColumnModel().getColumn(1).setMinWidth(0);
            tblPersonal.getTableHeader().getColumnModel().getColumn(1).setMaxWidth(0);
            tblPersonal.getTableHeader().getColumnModel().getColumn(1).setMinWidth(0);
            
            tblPersonal.getColumnModel().getColumn(2).setPreferredWidth(300);
            
            st.close();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Error al cargar los datos \n" + e);
        }
    }
    
    public void SearchDocumento(){
        String SQLBuscar = "SELECT * FROM vst_personal WHERE numero = " + this.txtNumero.getText();
        ConexionBase Conectado = new ConexionBase();
        con3 = Conectado.getConnection();

        try {
            st = (Statement) con3.createStatement();
            rs = st.executeQuery(SQLBuscar);
            
            ValidarDocumento = false;
            
            while (rs.next()) {
                ValidarDocumento = true;
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Error al cargar los datos \n" + e);
        }
    }
    
    public void SearchPersonal(){
        String SQLBuscar = "SELECT * FROM vst_personal WHERE id = " + this.txtId.getText();
        ConexionBase Conectado = new ConexionBase();
        con3 = Conectado.getConnection();

        try {
            st = (Statement) con3.createStatement();
            rs = st.executeQuery(SQLBuscar);
            
            int count = 0;
            
            while (rs.next()) {
                cboPerfil.setSelectedItem(rs.getString("perfil"));
                cboEspecialidad.setSelectedItem(rs.getString("especialidad"));
                txtNombre.setText(rs.getString("nombre"));
                txtPaterno.setText(rs.getString("paterno"));
                txtMaterno.setText(rs.getString("materno"));
                cboGenero.setSelectedItem(rs.getString("genero"));
                txtFechaNacimiento.setText(rs.getString("fechanacimiento"));
                cboTipoDocumento.setSelectedItem(rs.getString("tipodocumento"));
                txtNumero.setText(rs.getString("numero"));
                cboDistrito.setSelectedItem(rs.getString("distrito"));
                txtDireccion.setText(rs.getString("direccion"));
                txtTelefono.setText(rs.getString("telefono"));
                txtCelular.setText(rs.getString("celular"));
                txtCorreo.setText(rs.getString("correo"));
                chkEstado.setSelected(rs.getBoolean("estado"));
            }
            
            tblPersonal.setModel(TablaPersonal);
            
            tblPersonal.getColumnModel().getColumn(0).setPreferredWidth(50);
            
            tblPersonal.getColumnModel().getColumn(1).setMaxWidth(0);
            tblPersonal.getColumnModel().getColumn(1).setMinWidth(0);
            tblPersonal.getTableHeader().getColumnModel().getColumn(1).setMaxWidth(0);
            tblPersonal.getTableHeader().getColumnModel().getColumn(1).setMinWidth(0);
            
            tblPersonal.getColumnModel().getColumn(2).setPreferredWidth(300);
            
            st.close();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Error al cargar los datos \n" + e);
        }
    }
    
    public void CargarPerfil(){
        String SQLBuscar = "SELECT id, descripcion, estado FROM vst_perfil WHERE estado = true ORDER BY descripcion ASC";
        ConexionBase Conectado = new ConexionBase();
        con3 = Conectado.getConnection();

        try {
            st = (Statement) con3.createStatement();
            rs = st.executeQuery(SQLBuscar);
            
            cboPerfil.removeAllItems();
            cboPerfil.addItem("SELECCIONE");
            
            while (rs.next()) {
                cboPerfil.addItem(rs.getString("descripcion"));
            }
            
            st.close();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Error al cargar los datos \n" + e);
        }
    }
    
    public void CargarEspecialidad(){
        String SQLBuscar = "SELECT id, nombre, estado FROM vst_especialidad WHERE estado = true ORDER BY nombre ASC";
        ConexionBase Conectado = new ConexionBase();
        con3 = Conectado.getConnection();
        
        try {
            st = (Statement) con3.createStatement();
            rs = st.executeQuery(SQLBuscar);
            
            cboEspecialidad.removeAllItems();
            cboEspecialidad.addItem("SELECCIONE");
            
            while (rs.next()) {
                cboEspecialidad.addItem(rs.getString("nombre"));
            }
            
            st.close();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Error al cargar los datos \n" + e);
        }
    }
    
    public void CargarGenero(){
        String SQLBuscar = "SELECT id, codigo, nombre, estado FROM vst_genero WHERE estado = true ORDER BY nombre ASC";
        ConexionBase Conectado = new ConexionBase();
        con3 = Conectado.getConnection();
        
        try {
            st = (Statement) con3.createStatement();
            rs = st.executeQuery(SQLBuscar);
            
            cboGenero.removeAllItems();
            cboGenero.addItem("SELECCIONE");
            
            while (rs.next()) {
                cboGenero.addItem(rs.getString("nombre"));
            }
            
            st.close();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Error al cargar los datos \n" + e);
        }
    }
    
    public void CargarTipoDocumento(){
        String SQLBuscar = "SELECT id, nombre, descripcion, estado FROM vst_tipodocumento WHERE estado = true ORDER BY nombre ASC";
        ConexionBase Conectado = new ConexionBase();
        con3 = Conectado.getConnection();
        
        try {
            st = (Statement) con3.createStatement();
            rs = st.executeQuery(SQLBuscar);
            
            cboTipoDocumento.removeAllItems();
            cboTipoDocumento.addItem("SELECCIONE");
            
            while (rs.next()) {
                cboTipoDocumento.addItem(rs.getString("descripcion"));
            }
            
            st.close();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Error al cargar los datos \n" + e);
        }
    }
    
    public void CargarDistrito(){
        String SQLBuscar = "SELECT id, nombre, estado FROM vst_distrito WHERE estado = true ORDER BY nombre ASC";
        ConexionBase Conectado = new ConexionBase();
        con3 = Conectado.getConnection();
        
        try {
            st = (Statement) con3.createStatement();
            rs = st.executeQuery(SQLBuscar);
            
            cboDistrito.removeAllItems();
            cboDistrito.addItem("SELECCIONE");
            
            while (rs.next()) {
                cboDistrito.addItem(rs.getString("nombre"));
            }
            
            st.close();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Error al cargar los datos \n" + e);
        }
    }
    
    public void SearchPerfil(){
        String SQLBuscar = "Select id, descripcion, estado FROM vst_perfil WHERE descripcion = '" + this.cboPerfil.getSelectedItem() + "'";
        ConexionBase Conectado = new ConexionBase();
        con3 = Conectado.getConnection();
        
        try {
            st = (Statement) con3.createStatement();
            rs = st.executeQuery(SQLBuscar);
            
            lblIdPerfil.setText("0");
            
            while (rs.next()) {
                lblIdPerfil.setText(rs.getString("id"));
            }
            
            st.close();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Error al cargar los datos \n" + e);
        }
    }
    
    public void SearchEspecialidad(){
        String SQLBuscar = "Select id, nombre, estado FROM vst_especialidad WHERE nombre = '" + this.cboEspecialidad.getSelectedItem() + "'";
        ConexionBase Conectado = new ConexionBase();
        con3 = Conectado.getConnection();

        try {
            st = (Statement) con3.createStatement();
            rs = st.executeQuery(SQLBuscar);
            
            lblIdEspecialidad.setText("0");
            
            while (rs.next()) {
                lblIdEspecialidad.setText(rs.getString("id"));
            }
            
            st.close();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Error al cargar los datos \n" + e);
        }
    }
    
    public void SearchGenero(){
        String SQLBuscar = "Select id, codigo, nombre, estado FROM vst_genero WHERE nombre = '" + this.cboGenero.getSelectedItem() + "'";
        ConexionBase Conectado = new ConexionBase();
        con3 = Conectado.getConnection();

        try {
            st = (Statement) con3.createStatement();
            rs = st.executeQuery(SQLBuscar);
            
            lblIdGenero.setText("0");
            
            while (rs.next()) {
                lblIdGenero.setText(rs.getString("id"));
            }
            
            st.close();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Error al cargar los datos \n" + e);
        }
    }
    
    public void SearchTipoDocumento(){
        String SQLBuscar = "Select id, nombre, descripcion, estado FROM vst_tipodocumento WHERE descripcion = '" + this.cboTipoDocumento.getSelectedItem() + "'";
        ConexionBase Conectado = new ConexionBase();
        con3 = Conectado.getConnection();

        try {
            st = (Statement) con3.createStatement();
            rs = st.executeQuery(SQLBuscar);
            
            lblIdTipoDocumento.setText("0");
            
            while (rs.next()) {
                lblIdTipoDocumento.setText(rs.getString("id"));
            }
            
            st.close();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Error al cargar los datos \n" + e);
        }
    }
    
    public void SearchDistito(){
        String SQLBuscar = "Select id, nombre, estado FROM vst_distrito WHERE nombre = '" + this.cboDistrito.getSelectedItem() + "'";
        ConexionBase Conectado = new ConexionBase();
        con3 = Conectado.getConnection();

        try {
            st = (Statement) con3.createStatement();
            rs = st.executeQuery(SQLBuscar);
            
            lblIdDistrito.setText("0");
            
            while (rs.next()) {
                lblIdDistrito.setText(rs.getString("id"));
            }
            
            st.close();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Error al cargar los datos \n" + e);
        }
    }
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        txtId = new javax.swing.JTextField();
        jLabel2 = new javax.swing.JLabel();
        cboPerfil = new javax.swing.JComboBox<>();
        jLabel3 = new javax.swing.JLabel();
        cboEspecialidad = new javax.swing.JComboBox<>();
        jLabel4 = new javax.swing.JLabel();
        txtNombre = new javax.swing.JTextField();
        jLabel5 = new javax.swing.JLabel();
        txtPaterno = new javax.swing.JTextField();
        jLabel6 = new javax.swing.JLabel();
        txtMaterno = new javax.swing.JTextField();
        jLabel7 = new javax.swing.JLabel();
        cboGenero = new javax.swing.JComboBox<>();
        jLabel8 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        cboTipoDocumento = new javax.swing.JComboBox<>();
        jLabel10 = new javax.swing.JLabel();
        txtNumero = new javax.swing.JTextField();
        jLabel11 = new javax.swing.JLabel();
        cboDistrito = new javax.swing.JComboBox<>();
        jLabel12 = new javax.swing.JLabel();
        txtDireccion = new javax.swing.JTextField();
        jLabel13 = new javax.swing.JLabel();
        txtTelefono = new javax.swing.JTextField();
        jLabel14 = new javax.swing.JLabel();
        txtCelular = new javax.swing.JTextField();
        jLabel15 = new javax.swing.JLabel();
        txtCorreo = new javax.swing.JTextField();
        chkEstado = new javax.swing.JCheckBox();
        jLabel16 = new javax.swing.JLabel();
        btnEditar = new javax.swing.JButton();
        btnCancelar = new javax.swing.JButton();
        btnNuevo = new javax.swing.JButton();
        btnGuardar = new javax.swing.JButton();
        btnCerrar = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        tblPersonal = new javax.swing.JTable();
        lblIdPerfil = new javax.swing.JLabel();
        lblIdEspecialidad = new javax.swing.JLabel();
        lblIdGenero = new javax.swing.JLabel();
        lblIdTipoDocumento = new javax.swing.JLabel();
        lblIdDistrito = new javax.swing.JLabel();
        txtFechaNacimiento = new javax.swing.JTextField();

        setTitle("Personal");

        jLabel1.setText("Id");

        jLabel2.setText("Perfil");

        cboPerfil.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));

        jLabel3.setText("Especialidad");

        cboEspecialidad.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));

        jLabel4.setText("Nombre");

        jLabel5.setText("Ap. Paterno");

        jLabel6.setText("Ap. Materno");

        jLabel7.setText("Género");

        cboGenero.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));

        jLabel8.setText("Fecha de Nacimiento");

        jLabel9.setText("Tipo de documento");

        cboTipoDocumento.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));

        jLabel10.setText("Número");

        jLabel11.setText("Distrito");

        cboDistrito.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));

        jLabel12.setText("Dirección");

        jLabel13.setText("Teléfono");

        jLabel14.setText("Celular");

        jLabel15.setText("Correo");

        chkEstado.setText("Activo");

        jLabel16.setText("Estado");

        btnEditar.setText("Editar");
        btnEditar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnEditarActionPerformed(evt);
            }
        });

        btnCancelar.setText("Cancelar");
        btnCancelar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnCancelarActionPerformed(evt);
            }
        });

        btnNuevo.setText("Nuevo");
        btnNuevo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnNuevoActionPerformed(evt);
            }
        });

        btnGuardar.setText("Guardar");
        btnGuardar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnGuardarActionPerformed(evt);
            }
        });

        btnCerrar.setText("Cerrar");
        btnCerrar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnCerrarActionPerformed(evt);
            }
        });

        tblPersonal.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        tblPersonal.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tblPersonalMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(tblPersonal);

        lblIdPerfil.setText("jLabel17");

        lblIdEspecialidad.setText("jLabel17");

        lblIdGenero.setText("jLabel17");

        lblIdTipoDocumento.setText("jLabel17");

        lblIdDistrito.setText("jLabel17");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel10)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel1)
                            .addComponent(jLabel2)
                            .addComponent(jLabel3)
                            .addComponent(jLabel4)
                            .addComponent(jLabel5)
                            .addComponent(jLabel6)
                            .addComponent(jLabel7)
                            .addComponent(jLabel8)
                            .addComponent(jLabel9)
                            .addComponent(jLabel11)
                            .addComponent(jLabel12)
                            .addComponent(jLabel13)
                            .addComponent(jLabel14)
                            .addComponent(jLabel15)
                            .addComponent(jLabel16))
                        .addGap(26, 26, 26)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(txtTelefono)
                            .addComponent(txtCelular, javax.swing.GroupLayout.PREFERRED_SIZE, 102, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(txtDireccion)
                            .addComponent(cboDistrito, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(cboTipoDocumento, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(txtId, javax.swing.GroupLayout.PREFERRED_SIZE, 78, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(cboEspecialidad, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(txtNombre)
                            .addComponent(txtMaterno)
                            .addComponent(txtPaterno)
                            .addComponent(cboPerfil, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(txtNumero, javax.swing.GroupLayout.DEFAULT_SIZE, 103, Short.MAX_VALUE)
                            .addComponent(txtCorreo)
                            .addComponent(cboGenero, 0, 103, Short.MAX_VALUE)
                            .addComponent(chkEstado, javax.swing.GroupLayout.PREFERRED_SIZE, 55, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(txtFechaNacimiento))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(lblIdPerfil, javax.swing.GroupLayout.PREFERRED_SIZE, 18, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(lblIdEspecialidad, javax.swing.GroupLayout.PREFERRED_SIZE, 18, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(lblIdGenero, javax.swing.GroupLayout.PREFERRED_SIZE, 18, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(lblIdTipoDocumento, javax.swing.GroupLayout.PREFERRED_SIZE, 18, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(lblIdDistrito, javax.swing.GroupLayout.PREFERRED_SIZE, 18, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addGroup(layout.createSequentialGroup()
                                .addGap(20, 20, 20)
                                .addComponent(btnNuevo, javax.swing.GroupLayout.PREFERRED_SIZE, 75, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(btnEditar, javax.swing.GroupLayout.PREFERRED_SIZE, 75, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(btnGuardar, javax.swing.GroupLayout.PREFERRED_SIZE, 75, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(btnCancelar)
                                .addGap(59, 59, 59)
                                .addComponent(btnCerrar, javax.swing.GroupLayout.PREFERRED_SIZE, 75, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(layout.createSequentialGroup()
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jScrollPane1)))))
                .addContainerGap(154, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(txtId, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel1))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel2)
                            .addComponent(cboPerfil, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(lblIdPerfil))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(cboEspecialidad, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel3)
                            .addComponent(lblIdEspecialidad))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(txtNombre, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel4))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(txtPaterno, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel5))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(txtMaterno, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel6))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(cboGenero, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel7)
                            .addComponent(lblIdGenero))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel8)
                            .addComponent(txtFechaNacimiento, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(cboTipoDocumento, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel9)
                            .addComponent(lblIdTipoDocumento))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel10)
                            .addComponent(txtNumero, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(10, 10, 10)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(cboDistrito, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel11)
                            .addComponent(lblIdDistrito))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(txtDireccion, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel12))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addGap(3, 3, 3)
                                .addComponent(jLabel13))
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(txtTelefono, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(txtCelular, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel14))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(txtCorreo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel15)))))
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel16)
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(btnNuevo)
                            .addComponent(btnEditar, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(btnGuardar)
                            .addComponent(btnCancelar, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(btnCerrar))
                        .addComponent(chkEstado)))
                .addGap(27, 27, 27))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnEditarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnEditarActionPerformed
        // TODO add your handling code here:
        Habilitar();
        transaccion="Editar";
        cboPerfil.requestFocus();
    }//GEN-LAST:event_btnEditarActionPerformed

    private void btnCancelarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCancelarActionPerformed
        // TODO add your handling code here:
        Deshabilitar();
        Limpiar();
    }//GEN-LAST:event_btnCancelarActionPerformed

    private void btnNuevoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnNuevoActionPerformed
        // TODO add your handling code here:
        Habilitar();
        Limpiar();
        transaccion="Nuevo";
        cboPerfil.requestFocus();
    }//GEN-LAST:event_btnNuevoActionPerformed

    private void btnGuardarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnGuardarActionPerformed
        // TODO add your handling code here:
        if(cboPerfil.getSelectedItem()=="SELECCIONE"){
            JOptionPane.showMessageDialog(null, "Seleccione un perfil");
            cboPerfil.requestFocus();
            return;
        }
        
        if(cboEspecialidad.getSelectedItem()=="SELECCIONE"){
            JOptionPane.showMessageDialog(null, "Seleccione una especialidad");
            cboEspecialidad.requestFocus();
            return;
        }
        
        if(txtNombre.getText().length()==0){
            JOptionPane.showMessageDialog(null, "Ingrese su nombre");
            txtNombre.requestFocus();
            return;
        }
        
        if(txtPaterno.getText().length()==0){
            JOptionPane.showMessageDialog(null, "Ingrese su apellido paterno");
            txtPaterno.requestFocus();
            return;
        }
        
        if(txtMaterno.getText().length()==0){
            JOptionPane.showMessageDialog(null, "Ingrese su apellido materno");
            txtMaterno.requestFocus();
            return;
        }
        
        if(cboGenero.getSelectedItem()=="SELECCIONE"){
            JOptionPane.showMessageDialog(null, "Seleccione un género");
            cboGenero.requestFocus();
            return;
        }
        
        if(cboTipoDocumento.getSelectedItem()=="SELECCIONE"){
            JOptionPane.showMessageDialog(null, "Seleccione un tipo de documento");
            cboTipoDocumento.requestFocus();
            return;
        }
        
        if(txtNumero.getText().length()==0){
            JOptionPane.showMessageDialog(null, "Ingrese su número de documento");
            txtNumero.requestFocus();
            return;
        }
        
        if(cboDistrito.getSelectedItem()=="SELECCIONE"){
            JOptionPane.showMessageDialog(null, "Seleccione un distrito");
            cboDistrito.requestFocus();
            return;
        }
        
        SearchDocumento();
        
        if(ValidarDocumento == true && transaccion=="Nuevo"){
            JOptionPane.showMessageDialog(null, "El documento ingresado ya se encuentra registrado");
            txtNumero.requestFocus();
        }else{
            SearchPerfil();
            SearchEspecialidad();
            SearchGenero();
            SearchTipoDocumento();
            SearchDistito();
            
            String SQLGuardar = "";
            
            Connection con1 = null;
            ConexionBase conectado = new ConexionBase();
            con1 = conectado.getConnection();
            //Statement st = con1.createStatement();

            if(transaccion=="Nuevo"){
                SQLGuardar = "INSERT INTO tbl_personal (id_perfil, id_especialidad, personal_nombre, personal_paterno, personal_materno, id_genero, personal_fechanacimiento, " + 
                                "id_tipodocumento, personal_numero, id_distrito, personal_direccion, personal_telefono, personal_celular, personal_correo, personal_estado) " + 
                                "VALUES (" + lblIdPerfil.getText() + ", " + lblIdEspecialidad.getText() + ", '" + txtNombre.getText().toUpperCase() + "', '" + txtPaterno.getText().toUpperCase() + 
                                "', '" + txtMaterno.getText().toUpperCase() + "', " + lblIdGenero.getText() + ", '" + txtFechaNacimiento.getText() + "', " + lblIdTipoDocumento.getText() + 
                                ", '" + txtNumero.getText().toUpperCase() + "', " + lblIdDistrito.getText() + ", '" + txtDireccion.getText().toUpperCase() + "', '" + txtTelefono.getText() + 
                                "', '" + txtCelular.getText() + "', '" + txtCorreo.getText().toUpperCase() + "', " + chkEstado.isSelected() + ")";
            }else{
                SQLGuardar = "UPDATE tbl_personal SET id_perfil = " + lblIdPerfil.getText() + ", id_especialidad = " + lblIdEspecialidad.getText() + 
                                ", personal_nombre = '" + txtNombre.getText().toUpperCase() + "', personal_paterno = '" + txtPaterno.getText().toUpperCase() + 
                                "', personal_materno = '" + txtMaterno.getText().toUpperCase() + "', id_genero = " + lblIdGenero.getText() + 
                                ", personal_fechanacimiento = '" + txtFechaNacimiento.getText() + "', id_tipodocumento = " + lblIdTipoDocumento.getText() + 
                                ", personal_numero = '" + txtNumero.getText().toUpperCase() + "', id_distrito = " + lblIdDistrito.getText() + 
                                ", personal_direccion = '" + txtDireccion.getText().toUpperCase() + "', personal_telefono = '" + txtTelefono.getText() + 
                                "', personal_celular = '" + txtCelular.getText() + "', personal_correo = '" + txtCorreo.getText().toUpperCase() + 
                                "', personal_estado = " + chkEstado.isSelected() + " WHERE id_personal = " + this.txtId.getText();
            }

            try {
                PreparedStatement pst = con1.prepareCall(SQLGuardar);

                int n = pst.executeUpdate();
                pst.close();

                if (n > 0) {
                    JOptionPane.showMessageDialog(null, "Datos guardados correctamente");
                    Deshabilitar();
                    CargarPersonal();
                }
            } catch (Exception e) {
                JOptionPane.showMessageDialog(null, "Error al guardar los datos \n" + e);
            }
        }
    }//GEN-LAST:event_btnGuardarActionPerformed

    private void btnCerrarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCerrarActionPerformed
        // TODO add your handling code here:
        dispose();
    }//GEN-LAST:event_btnCerrarActionPerformed

    private void tblPersonalMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tblPersonalMouseClicked
        // TODO add your handling code here:
        int seleccionar = tblPersonal.rowAtPoint(evt.getPoint());
        
        txtId.setText(String.valueOf(tblPersonal.getValueAt(seleccionar, 1)));
        SearchPersonal();
        btnEditar.setEnabled(true);
    }//GEN-LAST:event_tblPersonalMouseClicked


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnCancelar;
    private javax.swing.JButton btnCerrar;
    private javax.swing.JButton btnEditar;
    private javax.swing.JButton btnGuardar;
    private javax.swing.JButton btnNuevo;
    private javax.swing.JComboBox<String> cboDistrito;
    private javax.swing.JComboBox<String> cboEspecialidad;
    private javax.swing.JComboBox<String> cboGenero;
    private javax.swing.JComboBox<String> cboPerfil;
    private javax.swing.JComboBox<String> cboTipoDocumento;
    private javax.swing.JCheckBox chkEstado;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JLabel lblIdDistrito;
    private javax.swing.JLabel lblIdEspecialidad;
    private javax.swing.JLabel lblIdGenero;
    private javax.swing.JLabel lblIdPerfil;
    private javax.swing.JLabel lblIdTipoDocumento;
    private javax.swing.JTable tblPersonal;
    private javax.swing.JTextField txtCelular;
    private javax.swing.JTextField txtCorreo;
    private javax.swing.JTextField txtDireccion;
    private javax.swing.JTextField txtFechaNacimiento;
    private javax.swing.JTextField txtId;
    private javax.swing.JTextField txtMaterno;
    private javax.swing.JTextField txtNombre;
    private javax.swing.JTextField txtNumero;
    private javax.swing.JTextField txtPaterno;
    private javax.swing.JTextField txtTelefono;
    // End of variables declaration//GEN-END:variables
}
